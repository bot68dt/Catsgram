package ru.practicum.dinner;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    static DinnerConstructor dc;
    static Scanner scanner;

    public static void main(String[] args)
    {
        dc = new DinnerConstructor();
        while (true)
        {
            printMenu();
            Input command = new Input();
            switch (command.number(0,6))
            {
                case 1:
                    addNewDish();
                    break;
                case 2:
                    generateDishCombo();
                    break;
                case 3:
                    System.exit(0);
                case 4:
                    dc.generator(3,5);
                    break;
                case 5:
                    if (!dc.menu.isEmpty())
                    System.out.println(dc.menu);
                    break;
            }
        }
    }

    private static void printMenu() {
        System.out.println("Выберите команду:");
        System.out.println("1 - Добавить новое блюдо");
        System.out.println("2 - Сгенерировать комбинации блюд");
        System.out.println("3 - Выход");
        System.out.println("4 - Генерация рандомного меню для проверки");
        System.out.println("5 - Вывести меню");
    }

    private static void addNewDish()
    {
        Input dishType = new Input();
        Input dishName = new Input();
        System.out.println("Введите тип и название блюда, разделяя символом переноса строки (enter).");
        dc.addDish(dishType.text(), dishName.text());
    }

    private static void generateDishCombo() {

        if(dc.menu.isEmpty())
        {
            System.out.println("Меню отсутствует");
            return;
        }

        Input numberOfCombos = new Input();
        Input nextItem = new Input();
        System.out.println("Начинаем конструировать обед...");
        System.out.println("Введите количество наборов, которые нужно сгенерировать:");
        numberOfCombos.number(0,10000);
        System.out.println("Вводите типы блюда, разделяя символом переноса строки (enter). Для завершения ввода введите пустую строку");
        nextItem.text();

        ArrayList<String> random = new ArrayList<>();

        while (!nextItem.string.isEmpty())          //реализован ввод через Enter
        {
            while(!dc.menu.containsKey(nextItem.string))            //проверка на наличие категории в меню
            {
                System.out.println(nextItem + " -нет такой категории блюд, введите другую");
                nextItem.text();
            }
            random.add(nextItem.string);
            nextItem.text();
        }
        for(int i = 0; i <numberOfCombos.integer; i++)
            System.out.println(dc.randomMenu(random));          //генерируем рандомные связки блюд по введённой последовательности категорий, которые сохранили в лист random
    }
}





