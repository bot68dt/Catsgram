package ru.practicum.dinner;
import java.util.Scanner;


public class Input                                                 // т.к. конструкцию try-catch мы ещё не прошли, и в теории Шилдта я до неё не добрался - изобрёл для себя
{
    public String string = null;                                                                       // колесо, чтобы не ловить исключения при ошибках ввода
    public int integer= 0;
    Scanner scanner = new Scanner(System.in);

    String text()
    {
        while (scanner.hasNextLine())
        {
            string = scanner.nextLine();                        //пока у нас есть строка для считывания - пытаемся считать её и записать в переменную
            break;
        }
        return string;
    }

    Integer number(int min, int max)
    {
        while (!scanner.hasNextInt())
        {
            System.out.println("Введите число");
            scanner.nextLine();
        }
        integer = scanner.nextInt();
        if(integer>min && integer<max)
            return integer;
        else
            System.out.println("Значение недопустимо в данной программе :(");
        return 0;
    }
}

