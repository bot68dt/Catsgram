package ru.practicum.dinner;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.List;

public class DinnerConstructor {

    public HashMap<String, ArrayList<String>> menu; // создаём хеш-таблицу

    public DinnerConstructor()
    {
        menu = new HashMap<>();
    }

    public void addDish(String type, String dish)                   //добавляем блюдо по типу
    {
        for (ArrayList<String> t : menu.values())
            if(t.contains(dish))
            {
                System.out.println("Блюдо уже есть в меню");
                return;
            }
        if (menu.containsKey(type))
        {
            ArrayList<String> dishes = menu.get(type);
            dishes.add(dish);
            menu.put(type, dishes);
            System.out.println("Блюдо добавлено>");
        }
    }

    public ArrayList randomMenu(ArrayList<String> type)             //генерация рандомных связок блюд
    {
        ArrayList<String> returnMenu = new ArrayList<>();
        Random random = new Random();

        for (String k : type)                   //передаем в метод список, который формируем при вводе через Enter и проходим по каждому эл-ту спика. эл-ты = ключи основного класса
        {
            ArrayList<String> dishes;
            dishes = menu.get(k);
            if (!dishes.isEmpty())//считываем блюда, соответствующие типу, который идёт по порядку в сформированном списке для генерации связок
            returnMenu.add(dishes.get(random.nextInt(dishes.size())));
        }
        return returnMenu; //возвращаем готовый рандомный список
    }
    public void generator(int iter1, int iter2)             //для удобства проверок сделал рандомный генератор из двух неизменяемых списков
    {

        ArrayList<String> dishes;
        int size = 1;
        Random random = new Random();
        final List<String> first = List.of("Первое", "Второе", "Напитки", "Десерты");
        final List<String> second = List.of("Суп", "Плов", "Щи", "Гречка", "Запеканка", "Чай", "Газировка", "Компот", "Бульон", "Лапша" , "Пицца", "Пельмени", "Мороженое", "Рыба", "Сыр", "Печенье");
        String one;
        boolean mark=false;

        for (int i =0; i<iter1; i++)            //сначала забиваю типы рандомно
        {
            menu.put(first.get(random.nextInt(first.size())), new ArrayList<>());
        }
        for (String i : menu.keySet())          // тут особенно не заморачивался, главное - сделал так, чтобы каждое блюдо было уникальным для сгенерированного меню
        {
            for (int j =0; j<iter2; j++)
            {
                dishes=menu.get(i);
                one=second.get(random.nextInt(second.size()));
                for (ArrayList<String> t : menu.values())
                    if (t.contains(one))
                    {
                        mark = true;
                        break;
                    }
                if (!mark && dishes.isEmpty())
                {
                    dishes.add(one);
                    menu.put(i, dishes);
                }
                else
                {
                    if (!mark && dishes.size() <= size)
                    {
                        dishes.add(one);
                        menu.put(i, dishes);
                        size = dishes.size();
                    }
                }
            }
            mark = false;
        }
    }
}