package envs;

public class VerySmallTestOfVeryBigProduct {

}
