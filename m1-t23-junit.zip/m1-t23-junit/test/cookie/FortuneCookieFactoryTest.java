package cookie;

public class FortuneCookieFactoryTest {
}