package cookie;

public class FortuneCookieControllerTest {
}
