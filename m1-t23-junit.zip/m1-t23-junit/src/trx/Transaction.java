package trx;

public class Transaction {
    private int id;
    private int amount;
    private String from;
    private String to;
}
