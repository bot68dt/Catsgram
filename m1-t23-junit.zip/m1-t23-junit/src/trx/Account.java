package trx;

public class Account {
}
