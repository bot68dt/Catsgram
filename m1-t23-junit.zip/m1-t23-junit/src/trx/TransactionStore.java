package trx;

import java.util.HashMap;
import java.util.Map;

public class TransactionStore {

    private final Map<Integer, Transaction> map = new HashMap<>();

}
