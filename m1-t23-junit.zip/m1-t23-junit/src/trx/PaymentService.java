package trx;

public class PaymentService {

    public PaymentService(AccountsStore accounts) {

    }

    private AccountsStore accounts;

    public void processTransaction(Transaction trx) {

    }
}
