package delivery;

public enum TransportType {
    BIKE, CAR, TRUCK, DRONE
}