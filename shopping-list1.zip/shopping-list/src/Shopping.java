import java.util.Scanner;

public class Shopping {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in); //объекту сканер присваиваем метод сканер для считывания с консольного ввода
        String[] array1 = new String[4]; //базовый массив был задан - 4 позиции из задания
        int productCount = 0; //считаю кол-во введённых недублированных продуктов
        boolean overlap = false; //дубль продукта есть/нет
        System.out.println("Вас приветствует список покупок!");
        while(true) //работаем в беск.цикле по условию задачи
        {
            System.out.println("Выберите одну из команд:");
            System.out.println("1. Добавить товар в список");
            System.out.println("2. Показать список");
            System.out.println("3. Очистить список");
            System.out.println("4. Завершить работу");
            int actionNumber = scanner.nextInt(); //считываем ввод в int. не знаю пока, как работать с catch, чтобы исключать ввод стринг-переменных, в интернете гуглил что-то подобное
            switch (actionNumber) //выбираем из 4-х кодов и дефолт свитча сообщит, что введённый инт-символ не валиден для данной программы
            {

                case 1:
                    System.out.println("Введите наименование товара.Название должно быть написано без пробелов. Несколько слов нужно соединять символом подчёркивания. Например, так: «кокосовое_молоко», «молочный_шоколад», «зерновой_хлеб».");
                    String nameOfProduct = scanner.next(); //считываю название продукта
                    productCount++; //увеличиваю счётчик продуктов на 1
                    for (int k=0;k<(productCount-1);k++) //запускаю цикл на проверку дублей. если дубль, то пересечение = true
                    {
                        if (array1[k]!=null&&array1[k].equals(nameOfProduct)) //проверяю в лоб перебором + первое значение массива не нулевое на первом месте условия, чтобы не вызывать исключение при старте проги, когда ещё нет массива
                        {
                            System.out.println("Вы уже добавляли товар " + nameOfProduct + " в список.");
                            overlap = true;
                            --productCount;
                        }
                    }
                        if ((productCount)<=array1.length && !overlap) //если счётчик не превысил длину массива + нет дубля - вводим в массив товар
                        {
                            array1[productCount-1] = nameOfProduct;
                        }
                        if ((productCount)>array1.length && !overlap) // если мы заполнили весь массив + нет дубля - переинициализирую массив, сохраняя значения во вспомогательном, я видел операцию arrayList, она крутая, но надо без неё вроде, и мы её не проходили
                        {
                            System.out.println("Список полностью заполнен,увеличиваем список.Если хотите удалить введённые продукты и очистить список - воспользуйтесь функцией начального экрана.");
                            String[] array2 = new String[array1.length]; //ввожу доп.массив и просто переписываю его значениями первого
                            for (int t = 0; t < array1.length; t++) {
                                array2[t] = array1[t];
                            }
                            array1 = new String[((productCount-1)*2)]; //удвоил новый массив
                            for (int y = 0; y < array2.length; y++) {
                                array1[y] = array2[y];
                            }
                            //System.out.println(array1.length);
                            array1[productCount-1] = nameOfProduct; //докидываю последнее новое

                        }
                    overlap = false; //обнуляю для новых вводов счётчик дублей
                    break;
                case 2: //вывод на экран списка
                    if (productCount!=0) //если мы вообще вводили что-то живое без дублей
                    {
                        System.out.println("Ваш список товаров:"); //вывод на экран перебором в цикле
                        for (int i = 0; i < productCount; i++)
                        {
                            System.out.println((i + 1) + ". " + array1[i]);
                        }
                    }
                    else {System.out.println("Ваш список товаров пуст!");} // а если счётчик продуктов - 0, то список пустой, не выводим
                    break;
                case 3: //очищаем массив, задавая всем его переменны пустое значение, взял из подсказки к заданию
                    for (int j=0; j < array1.length; j++)
                    {
                        array1[j]=null;
                    }
                    productCount = 0;//соответственно, обнуляем кол-во введённых продуктов
                    System.out.println("Список товаров очищен.");
                    break;
                case 4: //выход из приложения операцией возврат
                    System.out.println("Работа приложения завершена");
                    return;
                default:
                    System.out.println("Такой команды нет"); //а тут - на случай если ввели инт неравный диапазону [1..4]
            }
        }
    }
}