import java.util.InputMismatchException;
import java.util.Scanner;

public class Shopping {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        ProductManager productManager = new ProductManager();
        final String[] commands = {"Добавить товар в список", "Отобразить список", "Очистить список", "Завершить программу"};
        boolean finished = false; // флаг завершения работы приложения

        System.out.println("Вас приветствует список покупок!");

        // основной цикл приложения
        while (!finished) {
            System.out.println("Выберите одну из команд:");
            for (int i = 0; i < commands.length; i++) {
                System.out.println((i + 1) + ". " + commands[i]);
            }
            int input;
            // обработка ввода пользователем не числового значения
            try {
                input = scanner.nextInt();
            } catch (InputMismatchException e) {
                input = 0;
                scanner.nextLine();
            }
            switch (input) {
                case 1: // добавление нового товара
                    System.out.println("Введите название товара:");
                    productManager.addProduct(scanner.next());
                    break;
                case 2: // вывод списка товаров
                    productManager.listProducts();
                    break;
                case 3: // очистка списка товаров
                    productManager.clearProducts();
                    break;
                case 4: // завершение работы приложения
                    finished = true;
                    break;
                default: // обработка ввода некорректной команды
                    System.out.println("Неизвестная команда!");
            }
        }
        System.out.println("До скорых встреч!");
    }
}
