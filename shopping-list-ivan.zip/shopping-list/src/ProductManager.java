public class ProductManager {
    private String[] productList;
    private int productCount;

    public ProductManager() {
        productList = new String[1];
        productCount = 0;
    }

    // добавление нового товара в список
    public void addProduct(String product) {
        // удвоение размера массива при превышении вместимости
        if (productList.length < productCount + 1) {
            final String[] bufferList = new String[productList.length * 2];
            System.arraycopy(productList, 0, bufferList, 0, productList.length);
            productList = bufferList;
        }
        // обработка дублирования товара
        for (int i = 0; i < productCount; i++) {
            if (productList[i].equals(product)) {
                System.out.println("Такой товар уже есть!");
                return;
            }
        }
        productList[productCount++] = product;
        System.out.println("Товар " + product + " добавлен в список под номером " + productCount);
    }

    // очистка списка товаров
    public void clearProducts() {
        productList = new String[1];
        productCount = 0;
        System.out.println("Список товаров очищен");
    }

    // вывод списка товаров
    public void listProducts() { //
        if (productCount == 0) {
            System.out.println("Список товаров пуст!");
        }
        for (int i = 0; i < productCount; i++) {
            System.out.println((i + 1) + ". " + productList[i]);
        }
    }
}