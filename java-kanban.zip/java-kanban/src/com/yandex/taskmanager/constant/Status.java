package com.yandex.taskmanager.constant;

public enum Status
{
    NEW,
    IN_PROGRESS,
    DONE
}