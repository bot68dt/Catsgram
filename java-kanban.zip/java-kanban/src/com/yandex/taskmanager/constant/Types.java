package com.yandex.taskmanager.constant;

public enum Types
{
    SIMPLE,
    SUBEPIC,
    EPIC
}
