package ru.practicum.dinner;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    static DinnerConstructor dc;
    static Scanner scanner;

    public static void main(String[] args)
    {
        dc = new DinnerConstructor();
        while (true)
        {
            printMenu();
            NoTryCatch command = new NoTryCatch(false, true);
            if (command.integer > 5)
                System.out.println("Такой команды нет");
            switch (command.integer) {
                case 1:
                    addNewDish();
                    break;
                case 2:
                    generateDishCombo();
                    break;
                case 3:
                    return;
                case 4:
                    dc.generator(3,5);
                    break;
                case 5:
                    if (!dc.menu.isEmpty())
                    System.out.println(dc.menu);
                    break;
            }
        }
    }

    private static void printMenu() {
        System.out.println("Выберите команду:");
        System.out.println("1 - Добавить новое блюдо");
        System.out.println("2 - Сгенерировать комбинации блюд");
        System.out.println("3 - Выход");
        System.out.println("4 - Генерация рандомного меню для проверки");
        System.out.println("5 - Вывести меню");
    }

    private static void addNewDish() {
        System.out.println("Введите тип блюда:");
        NoTryCatch dishType = new NoTryCatch(true,false);
        System.out.println("Введите название блюда:");
        NoTryCatch dishName = new NoTryCatch(true, false);
        dc.addDish(dishType.string, dishName.string);
        System.out.println("Блюдо добавлено>");
    }

    private static void generateDishCombo() {

        if(dc.menu.isEmpty())
        {
            System.out.println("Меню отсутствует");
            return;
        }

        System.out.println("Начинаем конструировать обед...");
        System.out.println("Введите количество наборов, которые нужно сгенерировать:");
        NoTryCatch numberOfCombos = new NoTryCatch(false, true);
        System.out.println("Вводите типы блюда, разделяя символом переноса строки (enter). Для завершения ввода введите пустую строку");
        NoTryCatch nextItem = new NoTryCatch(true, false);

        ArrayList<String> random = new ArrayList<>();

        while (!nextItem.string.isEmpty())          //реализован ввод через Enter
        {
            while(!dc.menu.containsKey(nextItem.string))            //проверка на наличие категории в меню
            {
                System.out.println(nextItem + " -нет такой категории блюд, введите другую");
                nextItem = new NoTryCatch(true, false);
            }
            random.add(nextItem.string);
            nextItem = new NoTryCatch(true, false);
        }
        for(int i = 0; i <numberOfCombos.integer; i++)
            System.out.println(dc.randomMenu(random));          //генерируем рандомные связки блюд по введённой последовательности категорий, которые сохранили в лист random
    }
}





