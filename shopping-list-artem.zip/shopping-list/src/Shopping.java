import java.util.Scanner;

public class Shopping {
    public static void main(String[] args) {
        System.out.println("Вас приветствует список покупок!");
        int totalproducts = 8;                                 // размер массива в первоначальном виде

        Scanner scanner = new Scanner(System.in);
        int productCount = 0;
        boolean proverka = true;                            //переменная для проверки одинаковых товаров
        int newleng = 0;                                      // переменная для новой длины массива
        String[] shoppingList = new String[totalproducts];          //объявляем массив до 8 товаров
        while (true) {

            System.out.println("Выберите одну из команд:");
            System.out.println("1. Добавить товар в список");
            System.out.println("2. Показать список");
            System.out.println("3. Очистить список");
            System.out.println("4. Завершить работу");

            int actionNumber = scanner.nextInt();          //считываем номер команды

            if (actionNumber == 1) {                  //обработка команды добавления товара

                if (productCount < totalproducts) {
                    System.out.println("Введите название товара:");
                    String productName = scanner.next();

                    for (int i = 0; i <= productCount; i++) {             //блок проверки одинаковых товаров
                        if (productName.equals(shoppingList[i])) {
                            proverka = false;

                        }
                    }
                    if (!proverka) {
                        System.out.println("Такой товар уже есть в списке!");
                        proverka = true;

                    } else {                               // добавляем товар в массив и выводим об этом сообщение

                        shoppingList[productCount] = productName;
                        productCount++;
                        System.out.println("Товар " + productName + " добавлен в список под номером " + productCount);
                    }


                } else {                                        // блок увеличения длины массива, в случае,
                                                                   // когда необходимо добавить больше 8 товаров

                    newleng = totalproducts * 2;                        // задаем новый размер массива
                    String[] shoppingList2 = new String[totalproducts];         // формируем промежуточный массив
                    for (int i = 0; i < totalproducts; i++) {                    //копируем в него первый массив
                        shoppingList2[i] = shoppingList[i];
                    }
                    shoppingList = new String[newleng];                //повторно объявляем первый массив,
                                                                       // так как вся работа программы заточена именно
                                                                       //  под массив с таким именем
                    for (int i = 0; i < totalproducts; i++) {
                        shoppingList[i] = shoppingList2[i];
                    }
                    totalproducts = totalproducts * 2;                // перезаписываем новое значение размера массива

                    System.out.println("Введите название товара:");    //далее идет повторение кода, который был выше
                                                                         // это необходимо, чтобы работала проверка на
                                                                       // одинаковый товар для 8-ой введенной единицы товара

                    String productName = scanner.next();

                    for (int i = 0; i <= productCount; i++) {
                        if (productName.equals(shoppingList[i])) {
                            proverka = false;

                        }
                    }
                    if (!proverka) {
                        System.out.println("Такой товар уже есть в списке!");
                        proverka = true;

                    } else {

                        shoppingList[productCount] = productName;
                        productCount++;
                        System.out.println("Товар " + productName + " добавлен в список под номером " + productCount);
                    }
                }

            } else if (actionNumber == 2) {                         // блок вывода списка товаров
                if (productCount > 0) {
                    for (int i = 0; i < productCount; i++) {
                        System.out.println((i + 1) + " " + shoppingList[i]);
                    }
                } else {
                    System.out.println("Список товаров пуст!");
                }
            } else if (actionNumber == 3) {                         //очистка списка товаров
                for (int i = 0; i < productCount; i++) {
                    shoppingList[i] = null;
                }
                System.out.println("Список товаров очищен");
                productCount = 0;
            } else if (actionNumber == 4) {                       //выход из программы
                break;
            } else {                                              //если введена неизвестная команда
                System.out.println("Неизвестная команда!");
            }

        }
    }
}

